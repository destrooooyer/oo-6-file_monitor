package oo;

/**
 * Created by DESTR on 2016/4/15.
 */
public class Test implements Runnable
{
	@Override
	public void run()
	{
		_file file = new _file();
//		System.out.println(123);
//		file.create_dir("E:\\test\\123\\testdir");
//		try
//		{
//			Thread.sleep(1000);
//		}
//		catch (InterruptedException e)
//		{
//			e.printStackTrace();
//		}
//		System.out.println(123);
//
//
//		file.move_file("E:\\test\\123\\asd (2).bak", "E:\\test\\123\\testdir\\asd (2).bak");
//		try
//		{
//			Thread.sleep(1000);
//		}
//		catch (InterruptedException e)
//		{
//			e.printStackTrace();
//		}
//		System.out.println(123);
//
//		file.create_file("E:\\test\\123\\testdir\\testfile.txt");
//		try
//		{
//			Thread.sleep(1000);
//		}
//		catch (InterruptedException e)
//		{
//			e.printStackTrace();
//		}
//
//		System.out.println(123);
//		file.file_append("E:\\test\\123\\testdir\\testfile.txt");
//		try
//		{
//			Thread.sleep(1000);
//		}
//		catch (InterruptedException e)
//		{
//			e.printStackTrace();
//		}
//
//		file.delete_file("E:\\test\\123\\testdir\\testfile.txt");
//		try
//		{
//			Thread.sleep(1000);
//		}
//		catch (InterruptedException e)
//		{
//			e.printStackTrace();
//		}
//
//		file.rename_file("E:\\test\\123\\testdir\\asd (2).bak", "E:\\test\\123\\testdir\\test.txt");
//		try
//		{
//			Thread.sleep(1000);
//		}
//		catch (InterruptedException e)
//		{
//			e.printStackTrace();
//		}
//
//		file.move_file("E:\\test\\123\\testdir\\test.txt", "E:\\test\\123\\test.txt");
//		try
//		{
//			Thread.sleep(1000);
//		}
//		catch (InterruptedException e)
//		{
//			e.printStackTrace();
//		}
//
//		file.delete_file("E:\\test\\123\\test.txt");
//		try
//		{
//			Thread.sleep(1000);
//		}
//		catch (InterruptedException e)
//		{
//			e.printStackTrace();
//		}
//		file.file_append("E:\\test\\123\\test.txt");
//		try
//		{
//			Thread.sleep(1000);
//		}
//		catch (InterruptedException e)
//		{
//			e.printStackTrace();
//		}
//		file.move_file("E:\\test\\123\\test.txt","E:\\test\\123\\testdir\\test.txt");
//		try
//		{
//			Thread.sleep(1000);
//		}
//		catch (InterruptedException e)
//		{
//			e.printStackTrace();
//		}
//		file.delete_file("E:\\test\\123\\test.txt");
//		try
//		{
//			Thread.sleep(1000);
//		}
//		catch (InterruptedException e)
//		{
//			e.printStackTrace();
//		}


	}

}
