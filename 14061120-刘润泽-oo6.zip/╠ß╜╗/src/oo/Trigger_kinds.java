package oo;

/**
 * Created by DESTR on 2016/4/13.
 */
public final class Trigger_kinds
{
	public static final int modified = 1;
	public static final int renamed = 2;
	public static final int path_changed = 3;
	public static final int size_changed = 4;

	public static final String[] trigger_kinds=new String[]{"wtf","modified","renamed","path-changed","size-changed"};
}
