package oo;

/**
 * Created by DESTRooooYER on 2016/4/14.
 */
public final class Action_kind
{
	public static final int record_summary = 1;
	public static final int record_detail = 2;
	public static final int recover = 3;

	public static final String[] action_kinds=new String[]{"wtf","record-summary","record-detail","recover"};
}
